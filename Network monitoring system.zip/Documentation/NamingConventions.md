# Network Monitoring System
## Naming Conventions

### 1. Folder Naming
- Use lowercase letters for folder names.
- Use meaningful names.
- Use plural names where applicable.

Examples:
- scripts
- reports
- pipelines

### 2. File Naming
- Use meaningful file names.
- Use lowercase letters.
- Use underscores to separate words in Python files.

Examples:
- network_scan.py
- connectivity_test.ps1
- test_cases.md

### 3. Variable Naming
- Use descriptive variable names.
- Use lowercase letters with underscores.

Example:
- ip_address
- host_status
- response_time

### 4. Function Naming
- Use meaningful function names.
- Use lowercase letters with underscores.

Example:
- check_connectivity()
- scan_network()

### 5. Documentation Naming
- Use Markdown (.md) format.
- Use clear and descriptive titles.

### 6. Pipeline Naming
- Use descriptive YAML file names.
- Use lowercase letters and hyphens.

Example:
- azure-pipelines.yml

## Conclusion
These naming conventions help maintain consistency, readability and easy management of the Network Monitoring System project.
